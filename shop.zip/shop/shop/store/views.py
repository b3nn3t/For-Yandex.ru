from django.http import Http404
from django.shortcuts import render, redirect
from .models import Category, Product, Review, Mail
from django.views.generic import ListView, DetailView
from .forms import LoginForm, RegistrationForm, ReviewForm, CustomerForm, ShippingForm, reverse
from django.contrib.auth import login, logout
from django.contrib import messages
from random import randint
import stripe
from .utils import CartForAnonymousUser, CartForAuthenticatedUser, get_cart_data, anonymous_order

# Create your views here.

class ProductList(ListView):
    model = Product
    context_object_name = 'categories'
    extra_context = {
        'title': 'Главная страница'
    }

    template_name = 'store/product_list.html'

    def get_queryset(self):
        categories = Category.objects.all()
        data = []

        for category in categories:
            products = Product.objects.filter(category=category, quantity__gt=0)[:4]
            data.append({
                'title': category.title,
                'products': products
            })
        return data


class ProductListByCategory(ListView):
    model = Product
    context_object_name = 'products'
    template_name = 'store/category_product_list.html'
    paginate_by = 8

    def get_queryset(self):
        sort_field = self.request.GET.get('sort')

        products = Product.objects.filter(
            category_id = self.kwargs['pk'],
            quantity__gt=0
        )
        if sort_field:
            products = products.order_by(sort_field)
        return products

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data()
        category = Category.objects.get(pk=self.kwargs['pk'])
        context['title'] = f'Категория: {category.title}'
        return context

    def dispatch(self, request, *args, **kwargs):
        try:
            super().dispatch(request, *args, **kwargs)
        except Http404:
            return redirect('product_list')
        return super().dispatch(request, *args, **kwargs)


class ProductDetail(DetailView):
    model = Product
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        products = Product.objects.filter(quantity__gt=0)
        data = []
        for i in range(4):
            random_index = randint(0, len(products)-1)
            product = products[random_index]
            if product not in data:
                data.append(product)
        context['products'] = data

        context['reviews'] = Review.objects.filter(product_id=self.kwargs['pk'])

        if self.request.user.is_authenticated:
            context['review_form'] = ReviewForm()

        return context

def login_registration(request):
    context = {
        'login_form': LoginForm(),
        'registration_form': RegistrationForm(),
        'title': 'Войти или зарегестрироваться'
    }
    return render(request, 'store/login_registration.html', context)



def register(request):
    form = RegistrationForm(data=request.POST)
    if form.is_valid():
        user = form.save()
        messages.success(request, 'Отлично! Вы прошли регистраци! Теперь вы можете авторизоваться!')
    else:
        return messages.error(request, 'Что-то пошло не так')
    return redirect('login_registration')


def user_login(request):
    form = LoginForm(data=request.POST)
    if form.is_valid():
        user = form.get_user()
        login(request, user)
        messages.success(request, 'Вы успешно зашли в аккаунт')
        return redirect('product_list')
    else:
        messages.error(request, 'Не верное имя пользователя или пароль')
        return redirect('login_registration')


def user_logout(request):
    logout(request)
    messages.warning(request,'Вы вышли из аккаунта')
    return redirect('product_list')


def save_mail(request):
    email = request.POST.get('email')
    print(email)
    user = request.user if request.user.is_authenticated else None
    if email:
        Mail.objects.create(mail=email, user=user)
    next_page = request.META.get('HTTP_REFERER', 'product_list')
    return redirect(next_page)


def save_review(request, product_id):
    form = ReviewForm(data=request.POST)
    if form.is_valid():
        review = form.save(commit=False)
        review.author = request.user
        review.product_id = product_id
        review.save()
    else:
        pass
    return redirect('product_detail', product_id)


def send_emails(request):
    from django.core.mail import send_mail
    from shop import settings
    if request.method == 'POST':
        text = request.POST.get('text')
        mail_list = Mail.objects.all()
        for email in mail_list:
            mail = send_mail(
                subject='У нас новая акция!',
                message=text,
                from_email=settings.EMAIL_HOST_USER,
                recipient_list=[email],
                fail_silently=False
            )
            print(f'Отправлено ли сообщение на {email}? - {bool(mail)}')
    else:
        pass
    return render(request, 'store/send_mail.html')


def cart(request):
    cart_info = get_cart_data(request)

    context = {
        'cart_total_quantity': cart_info['cart_total_quantity'],
        'order': cart_info['order'],
        'products': cart_info['products']
    }

    return render(request, 'store/cart.html', context)

def to_cart(request, product_id, action): # action - Добавить или удалить
    if not request.user.is_authenticated:
        session_cart = CartForAnonymousUser(request, product_id, action)
    else:
        user_cart = CartForAuthenticatedUser(request, product_id, action)
    return redirect('cart')


def checkout(request):
    cart_data = get_cart_data(request)

    context = {
        'customer_form': CustomerForm(),
        'shipping_form': ShippingForm(),
        'title': "Оформление заказа",
        'cart_total_quantity': cart_data['cart_total_quantity'],
        'order': cart_data['order'],
        'items': cart_data['products']
    }


    return render(request, 'store/checkout.html', context)


def create_checkout_session(request):
    from shop import settings
    stripe.api_key = settings.STRIPE_SECRET_KEY
    if request.method == 'POST':
        if not request.user.is_authenticated:
            user_cart = CartForAnonymousUser(request)
        else:
            user_cart = CartForAuthenticatedUser(request)

        cart_info = user_cart.get_cart_info()
        print('cart_info', cart_info)
        total_price = cart_info['cart_total_price']

        print('Общая цена корзины: ', total_price)
        session = stripe.checkout.Session.create(
            line_items = [
                {
                    'price_data':{
                        'currency': 'usd',
                        'product_data': {
                            'name': 'Товары с TOTEMBO'
                        },
                        'unit_amount': int(total_price * 100)
                    },
                    'quantity': 1
                }
            ],
            mode='payment',
            success_url = request.build_absolute_uri(reverse('successPayment')),
            cancel_url = request.build_absolute_uri(reverse('successPayment'))
        )
        return redirect(session.url, 303)


def successPayment(request):
    if not request.user.is_authenticated:
        user_cart = CartForAnonymousUser(request)
    else:
        user_cart = CartForAuthenticatedUser(request)
    user_cart.clear()
    messages.success(request,'Оплата прошла успешно')
    return render(request, 'store/success.html')

# Написать функцию cancelPayment - если оплата не прошла
# cart_info = get_cart_data(request) обернуть в if
# И пробовать взять информацию у незарегестрированого пользователя

















