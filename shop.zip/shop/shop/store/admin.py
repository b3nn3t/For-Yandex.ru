from django.contrib import admin
from .models import Category, Product, Review, Mail, Order, OrderProduct, Customer, ShippingAddress
from django.utils.safestring import mark_safe


# Register your models here.


class ProductAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'price', 'quantity', 'created_at', 'get_photo')
    list_editable = ('price', 'quantity')
    list_display_links = ('title',)

    def get_photo(self, obj):
        if obj.image:
            return mark_safe(f'<img src="{obj.image.url}" width=75>')
        else:
            return '-'

    get_photo.short_description = 'Миниатюра'


class ReviewAdmin(admin.ModelAdmin):
    list_display = ('pk', 'cut_text', 'author', 'product', 'created_at')
    list_display_links = ('pk', 'cut_text')

    def cut_text(self, obj):
        if len(obj.text) > 40:
            return obj.text[:40] + '...'
        else:
            return obj.text


class CustomerAdmin(admin.ModelAdmin):
    list_display = ('pk', 'user', 'name', 'email')
    list_display_links = ('pk', 'user')


class OrderProductsInline(admin.TabularInline):
    model = OrderProduct
    extra = 0
    readonly_fields = ('product', 'quantity')


class OrderAdmin(admin.ModelAdmin):
    list_display = ('pk', 'customer', 'created_at', 'is_completed', 'get_count_products')
    list_display_links = ('pk', 'customer')
    list_editable = ('is_completed',)
    inlines = [OrderProductsInline]

    def get_count_products(self, obj):
        if obj.orderproduct_set:
            return len(obj.orderproduct_set.all())
        else:
            return '0'

    get_count_products.short_description = 'Общее кол-во уникальных продуктов'


class OrderProductAdmin(admin.ModelAdmin):
    list_display = ('pk', 'product', 'order', 'quantity', 'added_at')
    list_display_links = ('pk', 'product')


class CategoryAdmin(admin.ModelAdmin):
    list_display = ('pk', 'title', 'count_products')
    list_display_links = ('pk', 'title')

    def count_products(self, obj):
        if obj.product_set:
            return len(obj.product_set.all())
        else:
            return '0'

    count_products.short_description = 'Количество товаров'


class ShippingAdmin(admin.ModelAdmin):
    list_display = ('pk', 'customer', 'address', 'city', 'state', 'zipcode')


admin.site.register(Category, CategoryAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Review, ReviewAdmin)
admin.site.register(Mail)
admin.site.register(OrderProduct, OrderProductAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(Customer, CustomerAdmin)
admin.site.register(ShippingAddress, ShippingAdmin)
