from django.urls import path
from .views import *

urlpatterns = [
    path('api/category-list/', CategoryList.as_view()),
    path('api/category-detail/<int:pk>/', CategoryDetail.as_view()),

    path('api/user-list/', UserList.as_view())
]

# JS AJAX LARAVEL REACT VUE
