from rest_framework import serializers
from store.models import Category, Review, Product
from django.contrib.auth.models import User


# class CategorySerializer(serializers.Serializer):
#     id = serializers.IntegerField(read_only=True)
#     title = serializers.CharField(max_length=255)
#     image = serializers.ImageField(allow_null=True) # Может быть пустым
#
#     def create(self, validated_data):#  validated_data данные которые подаются
#         return Category.objects.create(**validated_data)
#
#     def update(self, instance, validated_data): # instance - объект который подается на обновление
#         instance.title = validated_data.get('title', instance.title)
#         instance.image = validated_data.get('image', instance.image)
#         instance.save()
#         return instance
#

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'title', 'image']


class UserSerializer(serializers.ModelSerializer):

    #review = serializers.PrimaryKeyRelatedField(many=True, queryset=Review.objects.all())

    class Meta:
        model = User
        fields = ['id', 'username', 'email']


