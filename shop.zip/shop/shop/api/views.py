from django.shortcuts import get_object_or_404
from django.http import JsonResponse, HttpResponse, Http404
from store.models import *
from .serializers import *
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.views import APIView
from rest_framework import generics
from rest_framework import status
from rest_framework.response import Response
from django.contrib.auth.models import User


class CategoryList(APIView):

    queryset = Category.objects.all()

    def get(self, request, format=None):
        categories = Category.objects.all()
        serializer = CategorySerializer(categories, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = CategorySerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CategoryDetail(APIView):

    queryset = Category.objects.all()

    def get_object(self, pk):
        category = get_object_or_404(Category, pk=pk)
        return category

    def get(self, request, pk, format=None):
        category = self.get_object(pk)
        serializer = CategorySerializer(category)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        category = self.get_object(pk)
        serializer = CategorySerializer(category, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        category = self.get_object(pk)
        category.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class UserList(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer

# @csrf_exempt # Отклоняем наличие токена защиты- чтобы работало без него
# def category_list(request):
#     if request.method == 'GET':
#         categories = Category.objects.all()
#         serializer = CategorySerializer(categories, many=True)
#         return JsonResponse(serializer.data, safe=False)
#         # safe=False - Чтобы не проверял на словарь, т.к. мы возвращаем список
#     elif request.method == 'POST':
#         data = JSONParser().parse(request)
#         serializer = CategorySerializer(data=data)
#         if serializer.is_valid():
#             serializer.save()
#             return JsonResponse(serializer.data, status=201) # Удалось создать
#         return JsonResponse(serializer.errors, status=400) # Ошибка
#
#
# @csrf_exempt
# def category_detail(request, pk): # Конкретная категория
#     category = get_object_or_404(Category, pk=pk) # Если такого не будет то вернется ошибка 404
#
#     if request.method == 'GET':
#         serializer = CategorySerializer(category)
#         return JsonResponse(serializer.data, status=200) # Все ОК
#
#     elif request.method == 'PUT': # На изменение
#         data = JSONParser().parse(request)
#         serializer = CategorySerializer(category, data=data) # Изменяем данные
#         if serializer.is_valid():
#             serializer.save()
#             return JsonResponse(serializer.data, status=200) # Все ОК
#         return JsonResponse(serializer.errors, status=400) # Ошибка
#
#     elif request.method == 'DELETE':
#         category.delete()
#         return HttpResponse(status=204)
